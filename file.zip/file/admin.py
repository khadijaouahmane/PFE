from django.contrib import admin
from .models import Video, PDFFile,VideoProb

admin.site.register(Video)
admin.site.register(PDFFile)
admin.site.register(VideoProb)
